<?php

namespace Tests\Feature\Admin;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Filament\Pages\Reports;
use App\Models\Order;
use App\Services\ReportingService;
use App\Services\StockService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\CreatesCymarketFixtures;
use Tests\TestCase;

/**
 * TOR §6.11 "Reporting & Management Dashboard" - Sales / Inventory /
 * Customers / Operations reports with export capability, gated per the
 * TOR §6.10 RBAC split (Inventory Officer: inventory only; Super Admin:
 * everything).
 */
class ReportsTest extends TestCase
{
    use CreatesCymarketFixtures, RefreshDatabase;

    protected function makePaidOrder(int $quantity = 2, array $overrides = []): Order
    {
        $zone = $this->makeDeliveryZone();
        $product = $this->makeProduct(['available_quantity' => 20, 'selling_price' => 20]);
        $customer = $this->makeCustomer();

        $order = Order::create(array_merge([
            'status' => OrderStatus::Paid,
            'user_id' => $customer->id,
            'delivery_recipient_name' => 'Test Customer',
            'delivery_phone' => '+233200000001',
            'delivery_zone_id' => $zone->id,
            'delivery_address_line' => '1 Test Street',
            'delivery_fee' => (float) $zone->fee_override,
            'subtotal' => 20 * $quantity,
            'total' => 20 * $quantity + (float) $zone->fee_override,
            'placed_at' => now()->subHours(3),
            'paid_at' => now()->subHours(2),
            'dispatched_at' => now()->subHour(),
            'delivered_at' => now(),
        ], $overrides));

        $order->items()->create([
            'product_id' => $product->id,
            'product_name' => $product->name,
            'sku' => $product->sku,
            'unit_price' => 20,
            'quantity' => $quantity,
            'line_total' => 20 * $quantity,
        ]);

        $order->payments()->create([
            'provider' => 'hubtel',
            'amount' => $order->total,
            'status' => PaymentStatus::Successful,
            'paid_at' => now(),
        ]);

        return $order->fresh(['items', 'payments']);
    }

    public function test_only_super_admin_and_inventory_officer_can_access_the_reports_page(): void
    {
        $superAdmin = $this->makeSuperAdmin();
        $officer = $this->makeInventoryOfficer();
        $customer = $this->makeCustomer();

        $this->actingAs($superAdmin);
        $this->assertTrue(Reports::canAccess());

        $this->actingAs($officer);
        $this->assertTrue(Reports::canAccess());

        $this->actingAs($customer);
        $this->assertFalse(Reports::canAccess());
    }

    public function test_sales_summary_reports_gross_net_and_refunded_revenue(): void
    {
        $this->makePaidOrder(2);
        $this->makePaidOrder(1, ['status' => OrderStatus::Cancelled]);

        $summary = app(ReportingService::class)->salesSummary(now()->subDay(), now()->addDay());

        $this->assertSame(1, $summary['order_count']);
        $this->assertEquals(55.0, $summary['gross_revenue']);
        $this->assertEquals(35.0, $summary['refunded_amount']);
        $this->assertEquals(20.0, $summary['net_revenue']);
    }

    public function test_sales_by_product_and_by_location_are_scoped_to_the_period(): void
    {
        $order = $this->makePaidOrder(3);

        $reporting = app(ReportingService::class);

        $byProduct = $reporting->salesByProduct(now()->subDay(), now()->addDay());
        $this->assertCount(1, $byProduct);
        $this->assertEquals(3, $byProduct->first()->units_sold);

        $byLocation = $reporting->salesByLocation(now()->subDay(), now()->addDay());
        $this->assertSame($order->deliveryZone->name, $byLocation->first()->location);
    }

    public function test_spoilage_write_offs_surface_manual_negative_stock_adjustments(): void
    {
        $product = $this->makeProduct(['available_quantity' => 30]);
        $officer = $this->makeInventoryOfficer();

        app(StockService::class)->manualAdjustment($product, -5, 'Spoiled produce', $officer->id);
        app(StockService::class)->manualAdjustment($product, 10, 'Fresh delivery', $officer->id);

        $writeOffs = app(ReportingService::class)->spoilageWriteOffs(now()->subDay(), now()->addDay());

        $this->assertCount(1, $writeOffs);
        $this->assertSame(5, $writeOffs->first()->quantity);
        $this->assertSame('Spoiled produce', $writeOffs->first()->note);
    }

    public function test_fulfilment_performance_averages_lifecycle_hand_off_times(): void
    {
        $this->makePaidOrder(1);

        $metrics = app(ReportingService::class)->fulfilmentPerformance(now()->subDay(), now()->addDay());

        $this->assertEquals(1.0, $metrics['avg_hours_placed_to_paid']);
        $this->assertEquals(1.0, $metrics['avg_hours_paid_to_dispatched']);
        $this->assertEquals(1.0, $metrics['avg_hours_dispatched_to_delivered']);
        $this->assertEquals(0.0, $metrics['cancellation_rate']);
    }

    public function test_inventory_officer_can_export_inventory_but_not_sales_report(): void
    {
        $officer = $this->makeInventoryOfficer();
        $this->makeProduct();

        $this->actingAs($officer)
            ->get(route('admin.reports.export', 'inventory'))
            ->assertOk();

        $this->actingAs($officer)
            ->get(route('admin.reports.export', 'sales'))
            ->assertForbidden();
    }

    public function test_super_admin_can_export_every_report(): void
    {
        $superAdmin = $this->makeSuperAdmin();
        $this->makePaidOrder(1);

        $this->actingAs($superAdmin);

        foreach (['sales', 'inventory', 'customers', 'operations'] as $report) {
            $this->get(route('admin.reports.export', $report))->assertOk();
        }
    }

    public function test_customers_cannot_export_any_report(): void
    {
        $customer = $this->makeCustomer();

        $this->actingAs($customer)
            ->get(route('admin.reports.export', 'inventory'))
            ->assertForbidden();
    }
}
