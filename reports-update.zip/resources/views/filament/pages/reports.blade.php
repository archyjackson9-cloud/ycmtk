<x-filament-panels::page>
    {{-- Period filter (TOR §6.11 "daily / weekly / monthly filters") --}}
    <x-filament::section>
        <div class="flex flex-wrap items-end gap-4">
            <div>
                <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Period</label>
                <select
                    wire:model.live="period"
                    class="mt-1 block w-48 rounded-lg border-gray-300 text-sm shadow-sm dark:border-gray-600 dark:bg-gray-800"
                >
                    <option value="today">Today</option>
                    <option value="this_week">This Week</option>
                    <option value="this_month">This Month</option>
                    <option value="custom">Custom Range</option>
                </select>
            </div>

            @if ($period === 'custom')
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">From</label>
                    <input type="date" wire:model.live="customFrom" class="mt-1 block rounded-lg border-gray-300 text-sm shadow-sm dark:border-gray-600 dark:bg-gray-800" />
                </div>
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">To</label>
                    <input type="date" wire:model.live="customTo" class="mt-1 block rounded-lg border-gray-300 text-sm shadow-sm dark:border-gray-600 dark:bg-gray-800" />
                </div>
            @endif

            <div class="text-sm text-gray-500 dark:text-gray-400">
                @php [$rangeFrom, $rangeTo, $rangeLabel] = $this->dateRange(); @endphp
                Showing <span class="font-medium">{{ $rangeLabel }}</span>
                ({{ $rangeFrom->format('d M Y') }} &ndash; {{ $rangeTo->format('d M Y') }})
            </div>
        </div>
    </x-filament::section>

    @if ($this->canSeeFinancialReports())
        {{-- Sales --}}
        <x-filament::section>
            <x-slot name="heading">Sales</x-slot>
            <x-slot name="headerEnd">
                <x-filament::button tag="a" :href="$this->exportUrl('sales')" icon="heroicon-o-arrow-down-tray" color="gray" size="sm">
                    Export CSV
                </x-filament::button>
            </x-slot>

            @php $sales = $this->salesSummary(); @endphp
            <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                @foreach ([
                    'Orders' => $sales['order_count'],
                    'Gross Revenue' => 'GHS '.number_format($sales['gross_revenue'], 2),
                    'Net Revenue' => 'GHS '.number_format($sales['net_revenue'], 2),
                    'Refunded' => 'GHS '.number_format($sales['refunded_amount'], 2),
                    'Delivery Fees' => 'GHS '.number_format($sales['delivery_fees'], 2),
                    'Avg Order Value' => 'GHS '.number_format($sales['average_order_value'] ?? 0, 2),
                ] as $label => $value)
                    <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                        <div class="text-xs text-gray-500 dark:text-gray-400">{{ $label }}</div>
                        <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $value }}</div>
                    </div>
                @endforeach
            </div>

            <div class="mt-6 grid gap-6 lg:grid-cols-3">
                <div>
                    <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">By Product</h4>
                    <table class="w-full text-sm">
                        <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Product</th><th class="pb-1 text-right">Units</th><th class="pb-1 text-right">Revenue</th></tr></thead>
                        <tbody>
                            @forelse ($this->salesByProduct() as $row)
                                <tr class="border-t border-gray-100 dark:border-gray-800">
                                    <td class="py-1">{{ $row->product }}</td>
                                    <td class="py-1 text-right">{{ $row->units_sold }}</td>
                                    <td class="py-1 text-right">GHS {{ number_format($row->revenue, 2) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="py-2 text-gray-400">No sales in this period.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <div>
                    <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">By Category</h4>
                    <table class="w-full text-sm">
                        <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Category</th><th class="pb-1 text-right">Units</th><th class="pb-1 text-right">Revenue</th></tr></thead>
                        <tbody>
                            @forelse ($this->salesByCategory() as $row)
                                <tr class="border-t border-gray-100 dark:border-gray-800">
                                    <td class="py-1">{{ $row->category }}</td>
                                    <td class="py-1 text-right">{{ $row->units }}</td>
                                    <td class="py-1 text-right">GHS {{ number_format($row->revenue, 2) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="py-2 text-gray-400">No sales in this period.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <div>
                    <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">By Location</h4>
                    <table class="w-full text-sm">
                        <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Zone</th><th class="pb-1 text-right">Orders</th><th class="pb-1 text-right">Revenue</th></tr></thead>
                        <tbody>
                            @forelse ($this->salesByLocation() as $row)
                                <tr class="border-t border-gray-100 dark:border-gray-800">
                                    <td class="py-1">{{ $row->location }}</td>
                                    <td class="py-1 text-right">{{ $row->orders }}</td>
                                    <td class="py-1 text-right">GHS {{ number_format($row->revenue, 2) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="py-2 text-gray-400">No sales in this period.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </x-filament::section>
    @endif

    {{-- Inventory (visible to Super Admin and Inventory Officer) --}}
    <x-filament::section>
        <x-slot name="heading">Inventory</x-slot>
        <x-slot name="headerEnd">
            <x-filament::button tag="a" :href="$this->exportUrl('inventory')" icon="heroicon-o-arrow-down-tray" color="gray" size="sm">
                Export CSV
            </x-filament::button>
        </x-slot>

        @php $inventory = $this->inventoryReport(); @endphp
        <div class="grid grid-cols-2 gap-4 sm:grid-cols-4">
            @foreach ([
                'Total SKUs' => $inventory['total_skus'],
                'Out of Stock' => $inventory['out_of_stock'],
                'Low Stock' => $inventory['low_stock'],
                'Inventory Valuation' => 'GHS '.number_format($inventory['inventory_valuation'], 2),
            ] as $label => $value)
                <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                    <div class="text-xs text-gray-500 dark:text-gray-400">{{ $label }}</div>
                    <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $value }}</div>
                </div>
            @endforeach
        </div>

        <div class="mt-6 grid gap-6 lg:grid-cols-3">
            <div>
                <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">Low Stock Alerts</h4>
                <table class="w-full text-sm">
                    <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Product</th><th class="pb-1 text-right">Sellable</th></tr></thead>
                    <tbody>
                        @forelse ($this->lowStockProducts() as $product)
                            <tr class="border-t border-gray-100 dark:border-gray-800">
                                <td class="py-1">{{ $product->name }}</td>
                                <td class="py-1 text-right">{{ $product->sellable_quantity }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="2" class="py-2 text-gray-400">Nothing low on stock.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div>
                <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">Spoilage / Write-Offs</h4>
                <table class="w-full text-sm">
                    <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Product</th><th class="pb-1 text-right">Qty</th><th class="pb-1">Note</th></tr></thead>
                    <tbody>
                        @forelse ($this->spoilageWriteOffs() as $movement)
                            <tr class="border-t border-gray-100 dark:border-gray-800">
                                <td class="py-1">{{ $movement->product?->name ?? 'Deleted product' }}</td>
                                <td class="py-1 text-right">{{ $movement->quantity }}</td>
                                <td class="py-1 text-gray-500 dark:text-gray-400">{{ $movement->note }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="py-2 text-gray-400">No write-offs in this period.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div>
                <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">Stock Movement History</h4>
                <table class="w-full text-sm">
                    <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Product</th><th class="pb-1">Type</th><th class="pb-1 text-right">Qty</th></tr></thead>
                    <tbody>
                        @forelse ($this->stockMovementHistory() as $movement)
                            <tr class="border-t border-gray-100 dark:border-gray-800">
                                <td class="py-1">{{ $movement->product?->name ?? 'Deleted product' }}</td>
                                <td class="py-1">{{ $movement->type->label() }}</td>
                                <td class="py-1 text-right">{{ $movement->quantity }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="py-2 text-gray-400">No stock movement in this period.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </x-filament::section>

    @if ($this->canSeeFinancialReports())
        {{-- Customers --}}
        <x-filament::section>
            <x-slot name="heading">Customers</x-slot>
            <x-slot name="headerEnd">
                <x-filament::button tag="a" :href="$this->exportUrl('customers')" icon="heroicon-o-arrow-down-tray" color="gray" size="sm">
                    Export CSV
                </x-filament::button>
            </x-slot>

            @php $customers = $this->customerReport(); @endphp
            <div class="grid grid-cols-2 gap-4 sm:grid-cols-4">
                @foreach ([
                    'New Customers' => $customers['new_customers'],
                    'Returning Customers' => $customers['returning_customers'],
                ] as $label => $value)
                    <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                        <div class="text-xs text-gray-500 dark:text-gray-400">{{ $label }}</div>
                        <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $value }}</div>
                    </div>
                @endforeach
            </div>

            <div class="mt-6 grid gap-6 lg:grid-cols-2">
                <div>
                    <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">Most Active (this period)</h4>
                    <table class="w-full text-sm">
                        <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Customer</th><th class="pb-1 text-right">Orders</th><th class="pb-1 text-right">Spent</th></tr></thead>
                        <tbody>
                            @forelse ($this->mostActiveCustomers() as $row)
                                <tr class="border-t border-gray-100 dark:border-gray-800">
                                    <td class="py-1">{{ $row->name }}</td>
                                    <td class="py-1 text-right">{{ $row->order_count }}</td>
                                    <td class="py-1 text-right">GHS {{ number_format($row->total_spent, 2) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="py-2 text-gray-400">No customer orders in this period.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <div>
                    <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">Lifetime Value (all-time)</h4>
                    <table class="w-full text-sm">
                        <thead><tr class="text-left text-xs text-gray-500 dark:text-gray-400"><th class="pb-1">Customer</th><th class="pb-1 text-right">Orders</th><th class="pb-1 text-right">LTV</th></tr></thead>
                        <tbody>
                            @forelse ($this->customerLifetimeValue() as $row)
                                <tr class="border-t border-gray-100 dark:border-gray-800">
                                    <td class="py-1">{{ $row->name }}</td>
                                    <td class="py-1 text-right">{{ $row->lifetime_orders }}</td>
                                    <td class="py-1 text-right">GHS {{ number_format($row->lifetime_value, 2) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="py-2 text-gray-400">No paid customers yet.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </x-filament::section>

        {{-- Operations --}}
        <x-filament::section>
            <x-slot name="heading">Operations</x-slot>
            <x-slot name="headerEnd">
                <x-filament::button tag="a" :href="$this->exportUrl('operations')" icon="heroicon-o-arrow-down-tray" color="gray" size="sm">
                    Export CSV
                </x-filament::button>
            </x-slot>

            @php $ops = $this->operationsReport(); $fulfilment = $this->fulfilmentPerformance(); @endphp

            <h4 class="mb-2 text-sm font-semibold text-gray-950 dark:text-white">Orders by Status</h4>
            <div class="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-8">
                @foreach (\App\Enums\OrderStatus::cases() as $status)
                    <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                        <div class="text-xs text-gray-500 dark:text-gray-400">{{ $status->label() }}</div>
                        <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $ops[$status->value] ?? 0 }}</div>
                    </div>
                @endforeach
            </div>

            <div class="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3">
                @foreach ([
                    'Gross Revenue' => 'GHS '.number_format($ops['gross_revenue'], 2),
                    'Net of Refunds' => 'GHS '.number_format($ops['net_revenue'], 2),
                    'Refunded' => 'GHS '.number_format($ops['refunded_amount'], 2),
                ] as $label => $value)
                    <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                        <div class="text-xs text-gray-500 dark:text-gray-400">{{ $label }}</div>
                        <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $value }}</div>
                    </div>
                @endforeach
            </div>

            <h4 class="mb-2 mt-6 text-sm font-semibold text-gray-950 dark:text-white">Fulfilment Performance</h4>
            <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
                @foreach ([
                    'Placed &rarr; Paid' => $fulfilment['avg_hours_placed_to_paid'],
                    'Paid &rarr; Dispatched' => $fulfilment['avg_hours_paid_to_dispatched'],
                    'Dispatched &rarr; Delivered' => $fulfilment['avg_hours_dispatched_to_delivered'],
                    'Placed &rarr; Delivered' => $fulfilment['avg_hours_placed_to_delivered'],
                ] as $label => $hours)
                    <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                        <div class="text-xs text-gray-500 dark:text-gray-400">{!! $label !!} (avg hrs)</div>
                        <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $hours ?? '—' }}</div>
                    </div>
                @endforeach
                <div class="rounded-lg border border-gray-200 p-3 dark:border-gray-700">
                    <div class="text-xs text-gray-500 dark:text-gray-400">Cancellation Rate</div>
                    <div class="text-lg font-semibold text-gray-950 dark:text-white">{{ $fulfilment['cancellation_rate'] }}%</div>
                </div>
            </div>
        </x-filament::section>
    @endif
</x-filament-panels::page>
