<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\ReportingService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * CSV export for the admin Reports page (TOR §6.11 "... with daily / weekly
 * / monthly filters and export capability"). Hand-rolled streamed CSV -
 * deliberately no Composer export package, to keep the dependency surface
 * (and the composer-resolution risk that comes with it) as small as
 * possible. Gated by the same RBAC the Reports page itself uses (TOR
 * §6.10): Sales/Customers/Operations are Super-Admin only, Inventory is
 * open to Super Admin and Inventory Officer alike.
 */
class ReportExportController extends Controller
{
    protected const FINANCIAL_REPORTS = ['sales', 'customers', 'operations'];

    public function __invoke(Request $request, string $report): StreamedResponse
    {
        $user = $request->user();

        abort_unless($user && $user->is_active, 403);

        if (in_array($report, self::FINANCIAL_REPORTS, true)) {
            abort_unless($user->isSuperAdmin(), 403);
        } else {
            abort_unless($user->hasAnyRole([
                config('cymarket.roles.super_admin'),
                config('cymarket.roles.inventory_officer'),
            ]), 403);
        }

        [$from, $to] = $this->resolveRange($request);
        $reporting = app(ReportingService::class);

        [$filename, $rows] = match ($report) {
            'sales' => ['sales-by-product', $this->salesByProductRows($reporting, $from, $to)],
            'inventory' => ['inventory-stock-levels', $this->inventoryRows()],
            'customers' => ['customer-lifetime-value', $this->customerRows($reporting)],
            'operations' => ['operations-by-status', $this->operationsRows($reporting, $from, $to)],
            default => abort(404),
        };

        $filename .= '-'.now()->format('Ymd-His').'.csv';

        return response()->streamDownload(function () use ($rows) {
            $handle = fopen('php://output', 'w');
            foreach ($rows as $row) {
                fputcsv($handle, $row);
            }
            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv']);
    }

    /**
     * @return array{0: Carbon, 1: Carbon}
     */
    protected function resolveRange(Request $request): array
    {
        $from = $request->query('from');
        $to = $request->query('to');

        return [
            $from ? Carbon::parse($from)->startOfDay() : now()->startOfMonth(),
            $to ? Carbon::parse($to)->endOfDay() : now()->endOfDay(),
        ];
    }

    protected function salesByProductRows(ReportingService $reporting, Carbon $from, Carbon $to): array
    {
        $rows = [['Product', 'SKU', 'Units Sold', 'Revenue (GHS)']];

        foreach ($reporting->salesByProduct($from, $to, 1000) as $row) {
            $rows[] = [$row->product, $row->sku, $row->units_sold, number_format((float) $row->revenue, 2, '.', '')];
        }

        return $rows;
    }

    protected function inventoryRows(): array
    {
        $rows = [['SKU', 'Product', 'Available Qty', 'Reserved Qty', 'Sellable Qty', 'Low Stock Threshold']];

        foreach (Product::query()->orderBy('name')->get() as $product) {
            $rows[] = [
                $product->sku,
                $product->name,
                $product->available_quantity,
                $product->reserved_quantity,
                $product->sellable_quantity,
                $product->low_stock_threshold ?? config('cymarket.default_low_stock_threshold'),
            ];
        }

        return $rows;
    }

    protected function customerRows(ReportingService $reporting): array
    {
        $rows = [['Customer', 'Phone', 'Lifetime Orders', 'Lifetime Value (GHS)', 'Average Order Value (GHS)']];

        foreach ($reporting->customerLifetimeValue(1000) as $row) {
            $rows[] = [
                $row->name,
                $row->phone,
                $row->lifetime_orders,
                number_format((float) $row->lifetime_value, 2, '.', ''),
                number_format((float) $row->average_order_value, 2, '.', ''),
            ];
        }

        return $rows;
    }

    protected function operationsRows(ReportingService $reporting, Carbon $from, Carbon $to): array
    {
        $rows = [['Metric', 'Value']];

        foreach ($reporting->operationsReport($from, $to) as $key => $value) {
            $rows[] = [ucwords(str_replace('_', ' ', (string) $key)), $value];
        }

        return $rows;
    }
}
