<?php

namespace App\Filament\Pages;

use App\Services\ReportingService;
use Carbon\Carbon;
use Filament\Pages\Page;

/**
 * Reporting & Management Dashboard (TOR §6.11): Sales / Inventory /
 * Customers / Operations reports with daily / weekly / monthly / custom
 * date filters and CSV export capability.
 *
 * RBAC (TOR §6.10): Super Admin sees every section. Inventory Officer
 * ("view and update orders ... manage stock levels, view inventory
 * reports. No access to ... pricing changes, or financial settings")
 * sees the Inventory section only - Sales, Customers and Operations are
 * financial/commercial reports and stay hidden for that role.
 */
class Reports extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-chart-bar-square';

    protected static ?string $navigationGroup = 'Administration';

    protected static ?int $navigationSort = 1;

    protected static string $view = 'filament.pages.reports';

    protected static ?string $title = 'Reports';

    /** @var string one of: today, this_week, this_month, custom */
    public string $period = 'this_month';

    public ?string $customFrom = null;

    public ?string $customTo = null;

    public static function canAccess(): bool
    {
        return auth()->user()?->hasAnyRole([
            config('cymarket.roles.super_admin'),
            config('cymarket.roles.inventory_officer'),
        ]) ?? false;
    }

    public function canSeeFinancialReports(): bool
    {
        return auth()->user()?->isSuperAdmin() ?? false;
    }

    public function updatedPeriod(): void
    {
        if ($this->period !== 'custom') {
            $this->customFrom = null;
            $this->customTo = null;
        }
    }

    /**
     * @return array{0: Carbon, 1: Carbon, 2: string}
     */
    public function dateRange(): array
    {
        $now = now();

        return match ($this->period) {
            'today' => [$now->copy()->startOfDay(), $now->copy()->endOfDay(), 'Today'],
            'this_week' => [$now->copy()->startOfWeek(), $now->copy()->endOfWeek(), 'This Week'],
            'custom' => [
                $this->customFrom ? Carbon::parse($this->customFrom)->startOfDay() : $now->copy()->startOfMonth(),
                $this->customTo ? Carbon::parse($this->customTo)->endOfDay() : $now->copy()->endOfDay(),
                'Custom Range',
            ],
            default => [$now->copy()->startOfMonth(), $now->copy()->endOfMonth(), 'This Month'],
        };
    }

    protected function service(): ReportingService
    {
        return app(ReportingService::class);
    }

    public function exportUrl(string $report): string
    {
        [$from, $to] = $this->dateRange();

        return route('admin.reports.export', [
            'report' => $report,
            'from' => $from->toDateString(),
            'to' => $to->toDateString(),
        ]);
    }

    // -----------------------------------------------------------------
    // Sales (Super Admin only)
    // -----------------------------------------------------------------

    public function salesSummary(): array
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->salesSummary($from, $to);
    }

    public function salesByProduct()
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->salesByProduct($from, $to, 15);
    }

    public function salesByCategory()
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->salesByCategory($from, $to);
    }

    public function salesByLocation()
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->salesByLocation($from, $to);
    }

    // -----------------------------------------------------------------
    // Inventory (Super Admin + Inventory Officer)
    // -----------------------------------------------------------------

    public function inventoryReport(): array
    {
        return $this->service()->inventoryReport();
    }

    public function lowStockProducts()
    {
        return $this->service()->lowStockProducts(15);
    }

    public function spoilageWriteOffs()
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->spoilageWriteOffs($from, $to, 15);
    }

    public function stockMovementHistory()
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->stockMovementHistory($from, $to, 15);
    }

    // -----------------------------------------------------------------
    // Customers (Super Admin only)
    // -----------------------------------------------------------------

    public function customerReport(): array
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->customerReport($from, $to);
    }

    public function mostActiveCustomers()
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->mostActiveCustomers($from, $to, 10);
    }

    public function customerLifetimeValue()
    {
        return $this->service()->customerLifetimeValue(10);
    }

    // -----------------------------------------------------------------
    // Operations (Super Admin only)
    // -----------------------------------------------------------------

    public function operationsReport(): array
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->operationsReport($from, $to);
    }

    public function fulfilmentPerformance(): array
    {
        [$from, $to] = $this->dateRange();

        return $this->service()->fulfilmentPerformance($from, $to);
    }
}
